Sample content for the finance assistant resources
